# DripLeafed
## A web game inspired by the game "A Dark Room"
Not all that much content in this game right now, still very much WIP
## Created By Guyde-Dev (PreModor Alpha on youtube)
Hope you enjoy playing!
## **CURRENT UPDATE** - ***BETA V1.0***
